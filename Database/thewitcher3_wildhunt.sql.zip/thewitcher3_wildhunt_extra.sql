
--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `login_witcher`
--
ALTER TABLE `login_witcher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `login_witcher`
--
ALTER TABLE `login_witcher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
