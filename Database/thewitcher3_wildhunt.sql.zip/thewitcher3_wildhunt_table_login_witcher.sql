
-- --------------------------------------------------------

--
-- Struktur dari tabel `login_witcher`
--

CREATE TABLE `login_witcher` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `region` varchar(50) NOT NULL,
  `profile` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `login_witcher`
--

INSERT INTO `login_witcher` (`id`, `name`, `username`, `password`, `region`, `profile`) VALUES
(2, 'John Doe', 'johndoe', 'john123', 'Vizima', 'vizima.jpg'),
(3, 'Defit Bagus Saputra', 'defitsaputra', 'defit123', 'Velen', 'Velen.jpg'),
(4, 'Tsaqif Hasbi Aghna Syarief', 'tsaqifsyarief', 'tsaqif123', 'Novigrad', 'Novigrad.jpg'),
(5, 'Daiva Paundra Gevano', 'daivagevano', 'daiva123', 'Skellige', 'Skellige.jpg');
